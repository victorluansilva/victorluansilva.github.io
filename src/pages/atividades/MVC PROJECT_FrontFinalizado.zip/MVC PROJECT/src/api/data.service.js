const dataService = {

};

export { dataService };
